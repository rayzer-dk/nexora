Nexora Soft — optional declarative theme for Nexora Commerce 3.4.7. Install only if desired.
