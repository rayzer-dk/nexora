<?php

declare(strict_types=1);

namespace Commerce\Core\Platform;

final class PlatformVersion
{
    public const VERSION = '3.5.0';
    public const CHANNEL = 'release-candidate';
    public const EXTENSION_API = '2.0';
    public const DATABASE_SCHEMA = 45;
    public const MIN_PHP = '8.4.0';
    public const MAX_PHP_EXCLUSIVE = '8.6.0';

    private function __construct()
    {
    }
}
